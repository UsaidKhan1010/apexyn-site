
# Apexyn Landing (GitHub + Netlify)

Cyber/neon landing page with cursor-reactive grid, sector gate, and demo chat.
Edit colors in `:root` in **index.html**. Swap your logo at **assets/logo.png**.

## 1) Create GitHub repo
```bash
mkdir apexyn-site && cd apexyn-site
# copy the files from this bundle into the folder
git init
git add .
git commit -m "feat: initial apexyn landing"
git branch -M main
git remote add origin https://github.com/<YOUR-USER>/apexyn-site.git
git push -u origin main
```

## 2) Connect Netlify
- Netlify → **Add new site** → **Import from Git** → GitHub → pick `apexyn-site`.
- Build command: **(empty)**
- Publish directory: **.**
- Functions directory: **netlify/functions** (already set in `netlify.toml`).

## 3) Custom domain
- Site settings → **Domain management** → Add `apexyn.site`.
- If not using Netlify DNS, add CNAME for `www` to your Netlify subdomain and set apex redirect to `www`.

## 4) Live editing workflow
- Edit `index.html` (copy in `sectorContent` and styles in `:root`).
- Commit + push → Netlify auto-deploys.
- Use branches + PRs for experiments; Netlify builds **Deploy Previews**.

## 5) Serverless function (later)
- File: `netlify/functions/chat.js` (placeholder now). 
- When ready, set `OPENAI_API_KEY` in Netlify **Site settings → Environment variables**.
- Update this function to call OpenAI and stream responses.

Generated 2025-08-23T07:04:00.139979
