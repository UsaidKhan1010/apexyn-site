
/**
 * Placeholder Netlify Function for chat.
 * Later: call OpenAI server-side and stream tokens.
 */
export async function handler(event) {
  try {
    const body = event.body ? JSON.parse(event.body) : {};
    const { message = "", sector = "realestate" } = body;

    // Simple echo until wired to OpenAI
    const reply = sector === "realestate"
      ? "This is a server-side placeholder. We'll connect GPT-4o here."
      : "Server-side placeholder for e-comm. GPT-4o will answer here.";

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ ok: true, reply, echo: message })
    };
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ ok:false, error: e.message }) };
  }
}
